from django.db import models

# Create your models here.

class Serach_results(models.Model):
	title = models.CharField(max_length=100)
	postdate = models.CharField(max_length=100,null =True,blank=True)
	url = models.URLField(max_length=200)
	destination = models.CharField(max_length=1000,null =True,blank=True)
	description = models.CharField(max_length=1000,null =True,blank=True)

class facebook(models.Model):
	name = models.CharField(max_length = 100)
	url = models.URLField(max_length=200)
