from django.shortcuts import render

# Create your views here.
from urllib.request import urlopen
from urllib.parse import quote_plus
import ipdb
from proxycrawl import CrawlingAPI, ScraperAPI, LeadsAPI, ScreenshotsAPI, StorageAPI
from .models import *


def index(request):
	if request.method == 'POST':
		name = request.POST.get('name')
		email = request.POST.get('email')
		mobile = request.POST.get('mobile')
		organization = request.POST.get('organization')
		destination = request.POST.get('destination')
		city = request.POST.get('city')
		if organization:
			org = (organization).replace(" ", "+")
		else:
			org = ""
		if destination:
			dest = (destination).replace(" ", "+")
		else:
			dest = ""
		RE = (name).replace(" ", "+") + "+" + org + "+" + email + "+" + mobile + "+" + dest + "+" + city
		google_url = 'https://google.com/search?q=' + RE
		bing_url = 'https://www.bing.com/search?q=' + RE
		# request_result=requests.get( url )
		scraper_api = ScraperAPI({ 'token': 'gQTbQvXkvATGvnrNb9LzEQ' })
		google_response = scraper_api.get(google_url) # scraping google api
		bing_response = scraper_api.get(bing_url)     # scraping bing api
		if google_response['status_code'] == 200 and bing_response['status_code'] == 200:
			for res in google_response['json']['searchResults']:
				gsearch_obj = Serach_results(title=res['title'],url=res['url']) #save data in DB
				if 'destination' in res:
					gsearch_obj.destination = res['destination'],
				if 'description' in res:
					gsearch_obj.description = res['description']
				if 'postDate' in res:
					gsearch_obj.description = res['postDate']
				gsearch_obj.save()
			for bres in bing_response['json']['searchResults']:
				bsearch_obj = Serach_results(title=bres['title'],url=bres['url'])
				if 'destination' in bres:
					bsearch_obj.destination = bres['destination']
				if 'description' in bres:
					bsearch_obj.destination = bres['description']
				if 'postDate' in bres:
					bsearch_obj.destination = bres['postDate']
				bsearch_obj.save()	

			return render(request,'searchresults.html',{'data':google_response['json']['searchResults'],'bingdata':bing_response['json']['searchResults']})
		else:
			if google_response['status_code'] == 200:
				for bres in google_response['json']['searchResults']:
					bsearch_obj = Serach_results(title=bres['title'],url=bres['url'])
					if 'destination' in bres:
						bsearch_obj.destination = bres['destination']
					if 'description' in bres:
						bsearch_obj.destination = bres['description']
					if 'postDate' in bres:
						bsearch_obj.postdate = bres['postDate']
					bsearch_obj.save()
				#Serach_results(title=google_response['json']['searchResults'][0]['title'],url=google_response['json']['searchResults'][0]['url'],destination=google_response['json']['searchResults'][0]['destination'],description=google_response['json']['searchResults'][0]['description'])
				return render(request,'searchresults.html',{'data':google_response['json']['searchResults'],'bingstatus':bing_response['status_code']})

			elif bing_response['status_code'] == 200:
				for res in bing_response['json']['searchResults']:
					gsearch_obj = Serach_results(title=res['title'],url=res['url']) #save data in DB
					if 'destination' in res:
						gsearch_obj.destination = res['destination'],
					if 'description' in res:
						gsearch_obj.description = res['description']
					if 'postDate' in res:
						gsearch_obj.postdate = res['postDate']
					gsearch_obj.save()
				#Serach_results(title=bing_response['json']['searchResults'][0]['title'],url=bing_response['json']['searchResults'][0]['url'],destination=bing_response['json']['searchResults'][0]['destination'],description=bing_response['json']['searchResults'][0]['description'])

				return render(request,'searchresults.html',{'bingdata':bing_response['json']['searchResults'],'status':google_response['status_code']})
			else:
		 		return render(request,'searchresults.html',{'status':google_response['status_code'],'bingstatus':bing_response['status_code']})




		
		# Creating soup from the fetched request
		#soup = bs4.BeautifulSoup(request_result.text,"html.parser")


	else:
		return render(request,'index.html')


# url = quote_plus('https://www.facebook.com/britneyspears')

# handler = urlopen('https://api.proxycrawl.com/?token=gQTbQvXkvATGvnrNb9LzEQ&url=' + url)

# print(thandler.read())
